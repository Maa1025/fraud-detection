import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Shield, AlertTriangle, DollarSign, Activity } from 'lucide-react';

const claimData = [
  { month: 'Jan', total: 45000, fraud: 125 },
  { month: 'Feb', total: 52000, fraud: 98 },
  { month: 'Mar', total: 48000, fraud: 142 },
  { month: 'Apr', total: 61000, fraud: 167 },
  { month: 'May', total: 55000, fraud: 134 },
  { month: 'Jun', total: 67000, fraud: 189 },
];

const fraudRatioData = [
  { name: 'Legitimate', value: 98.7, color: '#10b981' },
  { name: 'Fraudulent', value: 1.3, color: '#ef4444' },
];

export function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">Healthcare Fraud Detection Dashboard</h1>
        <p className="text-slate-600">Real-time insights into healthcare claim security</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Total Claims</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-1">67,284</div>
            <p className="text-xs text-green-600 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Fraudulent Detected</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-1">189</div>
            <p className="text-xs text-red-600 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +5% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Accuracy Rate</CardTitle>
            <Shield className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-1">98.7%</div>
            <p className="text-xs text-green-600 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +0.3% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Alerts Today</CardTitle>
            <Activity className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-1">23</div>
            <p className="text-xs text-slate-500 flex items-center">
              <TrendingDown className="w-3 h-3 mr-1" />
              -8% from yesterday
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="text-slate-900">Healthcare Claims Over Time</CardTitle>
            <CardDescription>Monthly claim trends and fraud detection</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={claimData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200" />
                <XAxis dataKey="month" className="text-slate-600" />
                <YAxis className="text-slate-600" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="total" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name="Total Claims"
                />
                <Line 
                  type="monotone" 
                  dataKey="fraud" 
                  stroke="#ef4444" 
                  strokeWidth={2}
                  name="Fraudulent"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="text-slate-900">Claim Status Distribution</CardTitle>
            <CardDescription>Ratio of legitimate vs fraudulent claims</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={fraudRatioData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {fraudRatioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => [`${value}%`, 'Percentage']}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-slate-900">Recent High-Risk Claims</CardTitle>
          <CardDescription>Latest claims flagged by detection system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { id: 'CLM-001', amount: '$2,450.00', location: 'General Hospital, NY', risk: 85, time: '2 minutes ago' },
              { id: 'CLM-002', amount: '$890.50', location: 'City Clinic, CA', risk: 72, time: '5 minutes ago' },
              { id: 'CLM-003', amount: '$3,200.00', location: 'Medical Center, TX', risk: 91, time: '8 minutes ago' },
            ].map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-900">{transaction.id}</p>
                    <p className="text-xs text-slate-500">{transaction.location} • {transaction.time}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-900">{transaction.amount}</p>
                  <p className="text-xs text-red-600">Risk: {transaction.risk}%</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}