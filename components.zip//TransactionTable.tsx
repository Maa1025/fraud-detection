import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Search, Filter, Download, AlertTriangle, CheckCircle } from 'lucide-react';

const claimData = [
  { id: 'CLM-001', date: '2025-01-10', amount: 2450.00, location: 'General Hospital, NY', status: 'fraud', risk: 85 },
  { id: 'CLM-002', date: '2025-01-10', amount: 890.50, location: 'City Medical Center, CA', status: 'fraud', risk: 72 },
  { id: 'CLM-003', date: '2025-01-10', amount: 125.99, location: 'Community Clinic, TX', status: 'legitimate', risk: 15 },
  { id: 'CLM-004', date: '2025-01-09', amount: 3200.00, location: 'Regional Hospital, FL', status: 'fraud', risk: 91 },
  { id: 'CLM-005', date: '2025-01-09', amount: 67.50, location: 'Family Practice, OH', status: 'legitimate', risk: 8 },
  { id: 'CLM-006', date: '2025-01-09', amount: 1750.00, location: 'Specialty Clinic, WA', status: 'legitimate', risk: 28 },
  { id: 'CLM-007', date: '2025-01-08', amount: 4500.00, location: 'Emergency Center, AZ', status: 'fraud', risk: 94 },
  { id: 'CLM-008', date: '2025-01-08', amount: 299.99, location: 'Urgent Care, NV', status: 'legitimate', risk: 12 },
];

export function TransactionTable() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [riskFilter, setRiskFilter] = useState('all');

  const filteredClaims = claimData.filter(transaction => {
    const matchesSearch = transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || transaction.status === statusFilter;
    const matchesRisk = riskFilter === 'all' || 
                       (riskFilter === 'high' && transaction.risk >= 70) ||
                       (riskFilter === 'medium' && transaction.risk >= 30 && transaction.risk < 70) ||
                       (riskFilter === 'low' && transaction.risk < 30);
    
    return matchesSearch && matchesStatus && matchesRisk;
  });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">Claims Monitor</h1>
        <p className="text-slate-600">Comprehensive view of all healthcare claims</p>
      </div>

      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900">Claims History</CardTitle>
              <CardDescription>Search, filter, and analyze healthcare claim data</CardDescription>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by Claim ID or Location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-slate-300 focus:border-blue-500"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="legitimate">Legitimate</SelectItem>
                <SelectItem value="fraud">Fraudulent</SelectItem>
              </SelectContent>
            </Select>
            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Risk Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="high">High Risk (70%+)</SelectItem>
                <SelectItem value="medium">Medium Risk (30-69%)</SelectItem>
                <SelectItem value="low">Low Risk (&lt;30%)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Claims Table */}
          <div className="rounded-md border border-slate-200">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead className="text-slate-700">Claim ID</TableHead>
                  <TableHead className="text-slate-700">Date</TableHead>
                  <TableHead className="text-slate-700">Amount</TableHead>
                  <TableHead className="text-slate-700">Location</TableHead>
                  <TableHead className="text-slate-700">Status</TableHead>
                  <TableHead className="text-slate-700">Risk Score</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClaims.map((transaction) => (
                  <TableRow key={transaction.id} className="hover:bg-slate-50">
                    <TableCell className="text-slate-900 font-mono">
                      {transaction.id}
                    </TableCell>
                    <TableCell className="text-slate-600">
                      {transaction.date}
                    </TableCell>
                    <TableCell className="text-slate-900">
                      ${transaction.amount.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-slate-600">
                      {transaction.location}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={transaction.status === 'fraud' ? 'destructive' : 'secondary'}
                        className={
                          transaction.status === 'fraud'
                            ? 'bg-red-100 text-red-800 hover:bg-red-100'
                            : 'bg-green-100 text-green-800 hover:bg-green-100'
                        }
                      >
                        {transaction.status === 'fraud' ? (
                          <AlertTriangle className="w-3 h-3 mr-1" />
                        ) : (
                          <CheckCircle className="w-3 h-3 mr-1" />
                        )}
                        {transaction.status === 'fraud' ? 'Fraudulent' : 'Legitimate'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${
                          transaction.risk >= 70 ? 'bg-red-500' :
                          transaction.risk >= 30 ? 'bg-yellow-500' : 'bg-green-500'
                        }`}></div>
                        <span className="text-slate-900">{transaction.risk}%</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredClaims.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              No claims found matching your criteria.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}