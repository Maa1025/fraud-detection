import React from 'react';
import { BarChart3, CreditCard, AlertTriangle, Home, Download } from 'lucide-react';
import { cn } from './ui/utils';
import logo from 'figma:asset/2574e883062eaf5b18546624ec84581d61dca86d.png';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'transactions', label: 'Claims', icon: CreditCard },
  { id: 'alerts', label: 'Alerts', icon: AlertTriangle },
  { id: 'download', label: 'Download', icon: Download },
];

export function Sidebar({ currentPage, onPageChange }: SidebarProps) {
  return (
    <div className="w-64 bg-white border-r border-slate-200 shadow-sm">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <div className="w-14 h-14 flex items-center justify-center">
            <img src={logo} alt="Deceit Logo" className="w-14 h-14" />
          </div>
          <div>
            <h2 className="text-xl text-slate-900">Deceit</h2>
            <p className="text-sm text-slate-500">Detection</p>
          </div>
        </div>
      </div>

      <nav className="px-4 pb-4">
        <div className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={cn(
                  "w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors",
                  currentPage === item.id
                    ? "bg-blue-50 text-blue-700 border-l-4 border-blue-600"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                )}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}