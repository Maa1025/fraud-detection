import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { AlertTriangle, Clock, MapPin, DollarSign, CreditCard, Filter, CheckCircle, X, Bot } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

const alertData = [
  {
    id: 'ALT-001',
    transactionId: 'CLM-001',
    timestamp: '2025-01-10 14:32:15',
    amount: 2450.00,
    location: 'General Hospital, NY',
    riskScore: 85,
    reason: 'Unusual claim amount for this procedure category',
    severity: 'high',
    status: 'pending',
    aiRecommendation: 'Review similar procedure codes from this provider over the past 30 days. Amount is 2.3x higher than typical claims for this procedure type. Recommend contacting provider for documentation.'
  },
  {
    id: 'ALT-002',
    transactionId: 'CLM-004',
    timestamp: '2025-01-09 09:45:22',
    amount: 3200.00,
    location: 'Regional Hospital, FL',
    riskScore: 91,
    reason: 'Provider anomaly - claim from new facility',
    severity: 'critical',
    status: 'pending',
    aiRecommendation: 'New provider detected with no claim history. Verify provider credentials and licensing status. Cross-reference with known legitimate providers in the region before processing.'
  },
  {
    id: 'ALT-003',
    transactionId: 'CLM-007',
    timestamp: '2025-01-08 22:18:47',
    amount: 4500.00,
    location: 'Emergency Center, AZ',
    riskScore: 94,
    reason: 'Multiple high-value claims in short timeframe',
    severity: 'critical',
    status: 'pending',
    aiRecommendation: 'Pattern indicates potential billing fraud. 5 claims over $3000 submitted within 48 hours. Recommend immediate investigation and temporary hold on payments from this provider.'
  },
  {
    id: 'ALT-004',
    transactionId: 'CLM-002',
    timestamp: '2025-01-10 11:22:33',
    amount: 890.50,
    location: 'City Medical Center, CA',
    riskScore: 72,
    reason: 'Duplicate procedure codes submitted same day',
    severity: 'medium',
    status: 'reviewed',
    aiRecommendation: 'Possible duplicate billing detected. Review patient records to confirm multiple procedures were actually performed. Check if this is an administrative error or intentional double billing.'
  },
  {
    id: 'ALT-005',
    transactionId: 'CLM-010',
    timestamp: '2025-01-07 16:55:12',
    amount: 1250.00,
    location: 'Specialty Clinic, WA',
    riskScore: 68,
    reason: 'Billing frequency anomaly - too many claims per patient',
    severity: 'medium',
    status: 'resolved',
    aiRecommendation: 'High claim frequency for single patient (12 visits in 30 days). While medically possible for chronic conditions, recommend review of treatment necessity and provider protocols.'
  },
];

export function AlertsPage() {
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [alerts, setAlerts] = useState(alertData);

  const filteredAlerts = alerts.filter(alert => {
    const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || alert.status === statusFilter;
    return matchesSeverity && matchesStatus;
  });

  const handleAlertAction = (alertId: string, action: 'approve' | 'reject') => {
    setAlerts(alerts.map(alert => 
      alert.id === alertId 
        ? { ...alert, status: action === 'approve' ? 'resolved' : 'dismissed' }
        : alert
    ));
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'dismissed': return 'bg-gray-100 text-gray-800';
      case 'reviewed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">Alerts & Notifications</h1>
        <p className="text-slate-600">Monitor and manage healthcare fraud detection alerts</p>
      </div>

      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Pending Alerts</p>
                <p className="text-2xl text-slate-900">
                  {alerts.filter(a => a.status === 'pending').length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Critical Alerts</p>
                <p className="text-2xl text-slate-900">
                  {alerts.filter(a => a.severity === 'critical').length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-slate-600">Avg Response Time</p>
              <p className="text-2xl text-slate-900">4.2m</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-slate-600">Resolution Rate</p>
              <p className="text-2xl text-slate-900">96.8%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Alert List */}
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900">Active Alerts</CardTitle>
              <CardDescription>Review and manage fraud detection alerts</CardDescription>
            </div>
            <div className="flex gap-3">
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="reviewed">Reviewed</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredAlerts.map((alert) => (
              <div key={alert.id} className="border border-slate-200 rounded-lg p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-3">
                      <h3 className="text-lg text-slate-900">{alert.id}</h3>
                      <Badge className={getSeverityColor(alert.severity)}>
                        {alert.severity.toUpperCase()}
                      </Badge>
                      <Badge className={getStatusColor(alert.status)}>
                        {alert.status.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-slate-600">{alert.reason}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl text-slate-900">${alert.amount.toLocaleString()}</p>
                    <p className="text-sm text-red-600">Risk: {alert.riskScore}%</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center space-x-2 text-slate-600">
                    <CreditCard className="w-4 h-4" />
                    <span>{alert.transactionId}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-600">
                    <MapPin className="w-4 h-4" />
                    <span>{alert.location}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-600">
                    <Clock className="w-4 h-4" />
                    <span>{alert.timestamp}</span>
                  </div>
                </div>

                {/* AI Recommendation */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0">
                      <Bot className="w-5 h-5 text-blue-600 mt-0.5" />
                    </div>
                    <div>
                      <h4 className="text-sm text-blue-900 mb-1">AI Recommendation</h4>
                      <p className="text-sm text-blue-800">{alert.aiRecommendation}</p>
                    </div>
                  </div>
                </div>

                {alert.status === 'pending' && (
                  <div className="flex items-center space-x-3 pt-2">
                    <Button 
                      size="sm" 
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => handleAlertAction(alert.id, 'approve')}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approve
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="border-red-300 text-red-600 hover:bg-red-50"
                      onClick={() => handleAlertAction(alert.id, 'reject')}
                    >
                      <X className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {filteredAlerts.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              No alerts found matching your criteria.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}