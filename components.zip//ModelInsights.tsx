import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Upload, Download, TrendingUp, Brain, Target, Zap, BarChart3 } from 'lucide-react';

const performanceData = [
  { week: 'Week 1', accuracy: 96.2, precision: 94.8, recall: 89.3 },
  { week: 'Week 2', accuracy: 97.1, precision: 95.6, recall: 91.2 },
  { week: 'Week 3', accuracy: 98.3, precision: 96.8, recall: 93.7 },
  { week: 'Week 4', accuracy: 98.7, precision: 97.2, recall: 94.1 },
];

const rocData = [
  { fpr: 0, tpr: 0 },
  { fpr: 0.1, tpr: 0.85 },
  { fpr: 0.2, tpr: 0.92 },
  { fpr: 0.3, tpr: 0.96 },
  { fpr: 0.4, tpr: 0.98 },
  { fpr: 0.5, tpr: 0.99 },
  { fpr: 1.0, tpr: 1.0 },
];

export function ModelInsights() {
  const [uploadStatus, setUploadStatus] = useState('');

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadStatus('Analyzing CSV file...');
      // Simulate file processing
      setTimeout(() => {
        setUploadStatus('Analysis complete! 1,247 transactions processed.');
      }, 2000);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">Model Insights</h1>
        <p className="text-slate-600">Healthcare fraud AI model performance metrics and testing tools</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Model Accuracy</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-2">98.7%</div>
            <Progress value={98.7} className="h-2" />
            <p className="text-xs text-green-600 mt-2 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +2.5% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Precision</CardTitle>
            <Zap className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-2">97.2%</div>
            <Progress value={97.2} className="h-2" />
            <p className="text-xs text-green-600 mt-2 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +1.8% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">Recall</CardTitle>
            <Brain className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-2">94.1%</div>
            <Progress value={94.1} className="h-2" />
            <p className="text-xs text-green-600 mt-2 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +3.2% from last month
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm text-slate-600">F1 Score</CardTitle>
            <BarChart3 className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-slate-900 mb-2">95.6%</div>
            <Progress value={95.6} className="h-2" />
            <p className="text-xs text-green-600 mt-2 flex items-center">
              <TrendingUp className="w-3 h-3 mr-1" />
              +2.1% from last month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="text-slate-900">Performance Trends</CardTitle>
            <CardDescription>Model performance metrics over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200" />
                <XAxis dataKey="week" className="text-slate-600" />
                <YAxis domain={[85, 100]} className="text-slate-600" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px'
                  }}
                  formatter={(value) => [`${value}%`, '']}
                />
                <Line 
                  type="monotone" 
                  dataKey="accuracy" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name="Accuracy"
                />
                <Line 
                  type="monotone" 
                  dataKey="precision" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  name="Precision"
                />
                <Line 
                  type="monotone" 
                  dataKey="recall" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  name="Recall"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="text-slate-900">ROC Curve</CardTitle>
            <CardDescription>Receiver Operating Characteristic analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={rocData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200" />
                <XAxis 
                  dataKey="fpr" 
                  domain={[0, 1]} 
                  type="number"
                  label={{ value: 'False Positive Rate', position: 'insideBottom', offset: -5 }}
                />
                <YAxis 
                  domain={[0, 1]} 
                  label={{ value: 'True Positive Rate', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px'
                  }}
                  formatter={(value) => [value.toFixed(2), '']}
                />
                <Area
                  type="monotone"
                  dataKey="tpr"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  fill="#3b82f6"
                  fillOpacity={0.1}
                />
              </AreaChart>
            </ResponsiveContainer>
            <div className="mt-4 text-center">
              <p className="text-sm text-slate-600">AUC Score: <span className="text-slate-900">0.963</span></p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Model Testing */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-slate-900">Model Testing</CardTitle>
          <CardDescription>Upload CSV files to test the fraud detection model</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <div className="space-y-2">
              <p className="text-lg text-slate-900">Upload Test Data</p>
              <p className="text-sm text-slate-500">
                Upload a CSV file with transaction data to test model performance
              </p>
            </div>
            <div className="mt-4">
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
                id="csv-upload"
              />
              <label htmlFor="csv-upload">
                <Button className="bg-blue-600 hover:bg-blue-700 cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Choose CSV File
                </Button>
              </label>
            </div>
            {uploadStatus && (
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">{uploadStatus}</p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600">Required Columns</p>
              <p className="text-xs text-slate-500 mt-1">amount, location, timestamp, merchant_category</p>
            </div>
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600">Max File Size</p>
              <p className="text-xs text-slate-500 mt-1">50MB per upload</p>
            </div>
            <div className="text-center p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600">Processing Time</p>
              <p className="text-xs text-slate-500 mt-1">~2-5 minutes</p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Download Sample CSV
            </Button>
            <Button variant="outline">
              View API Documentation
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Test Results */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-slate-900">Recent Test Results</CardTitle>
          <CardDescription>Historical model testing outcomes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { date: '2025-01-10', file: 'test_batch_001.csv', records: 1247, accuracy: 98.9, processingTime: '3m 24s' },
              { date: '2025-01-09', file: 'validation_set_dec.csv', records: 892, accuracy: 97.8, processingTime: '2m 18s' },
              { date: '2025-01-08', file: 'historical_data_q4.csv', records: 3456, accuracy: 98.2, processingTime: '8m 47s' },
            ].map((result, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="space-y-1">
                  <p className="text-sm text-slate-900">{result.file}</p>
                  <p className="text-xs text-slate-500">{result.date} • {result.records} records • {result.processingTime}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-900">{result.accuracy}% accuracy</p>
                  <Button variant="outline" size="sm" className="mt-1">
                    View Report
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}