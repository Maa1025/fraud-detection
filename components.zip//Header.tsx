import React from 'react';
import { Search, Bell, User, Settings } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import logo from 'figma:asset/2574e883062eaf5b18546624ec84581d61dca86d.png';

export function Header() {
  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <img src={logo} alt="Deceit Logo" className="w-8 h-8" />
            <span className="text-lg text-slate-900">Deceit</span>
          </div>
          <div className="relative flex-1 max-w-lg">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search claims, alerts..."
              className="pl-10 border-slate-300 focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm" className="relative">
            <Bell className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="w-4 h-4" />
          </Button>
          <div className="flex items-center space-x-3 pl-3 border-l border-slate-200">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="bg-blue-600 text-white">
                <User className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm text-slate-900">Asmaan Ahmad</p>
              <p className="text-xs text-slate-500">Healthcare Fraud Analyst</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}