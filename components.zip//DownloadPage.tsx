import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Download, FileText, Database, Calendar, Filter, CheckCircle, Clock, FileSpreadsheet } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

const exportOptions = [
  {
    id: 'claims-data',
    title: 'Claims Data Export',
    description: 'Complete healthcare claims database with fraud detection results',
    format: 'CSV',
    size: '45.2 MB',
    records: '67,284',
    icon: Database,
    lastUpdated: '2025-01-10 15:30:00'
  },
  {
    id: 'fraud-alerts',
    title: 'Fraud Alerts Report',
    description: 'All fraud detection alerts and their resolution status',
    format: 'PDF',
    size: '8.7 MB',
    records: '189',
    icon: FileText,
    lastUpdated: '2025-01-10 14:45:00'
  },
  {
    id: 'analytics-summary',
    title: 'Analytics Summary',
    description: 'Performance metrics and detection system analytics',
    format: 'XLSX',
    size: '3.2 MB',
    records: '24',
    icon: FileSpreadsheet,
    lastUpdated: '2025-01-10 12:00:00'
  },
  {
    id: 'provider-analysis',
    title: 'Provider Risk Analysis',
    description: 'Risk assessment data for healthcare providers',
    format: 'CSV',
    size: '12.8 MB',
    records: '1,247',
    icon: Database,
    lastUpdated: '2025-01-09 18:20:00'
  },
  {
    id: 'transaction-logs',
    title: 'Transaction Processing Logs',
    description: 'Detailed logs of all processed transactions',
    format: 'JSON',
    size: '156.4 MB',
    records: '67,284',
    icon: FileText,
    lastUpdated: '2025-01-10 16:00:00'
  }
];

const downloadHistory = [
  {
    id: 'DL-001',
    file: 'claims_data_2025_q1.csv',
    downloadedAt: '2025-01-10 14:32:15',
    size: '45.2 MB',
    status: 'completed'
  },
  {
    id: 'DL-002',
    file: 'fraud_alerts_report_jan.pdf',
    downloadedAt: '2025-01-09 11:22:44',
    size: '8.7 MB',
    status: 'completed'
  },
  {
    id: 'DL-003',
    file: 'provider_analysis_dec.csv',
    downloadedAt: '2025-01-08 16:45:12',
    size: '11.2 MB',
    status: 'completed'
  }
];

export function DownloadPage() {
  const [selectedFormat, setSelectedFormat] = useState('all');
  const [downloadingIds, setDownloadingIds] = useState<string[]>([]);

  const handleDownload = (exportId: string, filename: string) => {
    setDownloadingIds(prev => [...prev, exportId]);
    
    // Simulate download process
    setTimeout(() => {
      setDownloadingIds(prev => prev.filter(id => id !== exportId));
      
      // Create a mock download
      const link = document.createElement('a');
      link.href = 'data:text/plain;charset=utf-8,Mock data export file';
      link.download = filename;
      link.click();
    }, 2000);
  };

  const filteredExports = exportOptions.filter(option => 
    selectedFormat === 'all' || option.format.toLowerCase() === selectedFormat.toLowerCase()
  );

  const getFormatColor = (format: string) => {
    switch (format.toLowerCase()) {
      case 'csv': return 'bg-green-100 text-green-800';
      case 'pdf': return 'bg-red-100 text-red-800';
      case 'xlsx': return 'bg-blue-100 text-blue-800';
      case 'json': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">Data Export & Downloads</h1>
        <p className="text-slate-600">Export healthcare fraud detection data and reports</p>
      </div>

      {/* Export Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Available Exports</p>
                <p className="text-2xl text-slate-900">{exportOptions.length}</p>
              </div>
              <Download className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Records</p>
                <p className="text-2xl text-slate-900">67.3K</p>
              </div>
              <Database className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-slate-600">Data Size</p>
              <p className="text-2xl text-slate-900">226 MB</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200">
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-slate-600">Last Updated</p>
              <p className="text-2xl text-slate-900">Today</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Available Exports */}
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Available Data Exports</CardTitle>
              <CardDescription>Download healthcare fraud detection data in various formats</CardDescription>
            </div>
            <div className="flex gap-3">
              <Select value={selectedFormat} onValueChange={setSelectedFormat}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Formats</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="xlsx">Excel</SelectItem>
                  <SelectItem value="json">JSON</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredExports.map((exportOption) => {
              const Icon = exportOption.icon;
              const isDownloading = downloadingIds.includes(exportOption.id);
              
              return (
                <div key={exportOption.id} className="border border-slate-200 rounded-lg p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                        <Icon className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-3">
                          <h3 className="text-lg text-slate-900">{exportOption.title}</h3>
                          <Badge className={getFormatColor(exportOption.format)}>
                            {exportOption.format}
                          </Badge>
                        </div>
                        <p className="text-slate-600">{exportOption.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-slate-500">
                          <span>{exportOption.records} records</span>
                          <span>•</span>
                          <span>{exportOption.size}</span>
                          <span>•</span>
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>Updated {new Date(exportOption.lastUpdated).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <Button 
                        onClick={() => handleDownload(exportOption.id, `${exportOption.title.toLowerCase().replace(/\s+/g, '_')}.${exportOption.format.toLowerCase()}`)}
                        disabled={isDownloading}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        {isDownloading ? (
                          <>
                            <Clock className="w-4 h-4 mr-2 animate-spin" />
                            Preparing...
                          </>
                        ) : (
                          <>
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredExports.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              No exports found matching your criteria.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Download History */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Recent Downloads</CardTitle>
          <CardDescription>Your download history and completed exports</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {downloadHistory.map((download) => (
              <div key={download.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-900">{download.file}</p>
                    <p className="text-xs text-slate-500">
                      Downloaded on {new Date(download.downloadedAt).toLocaleDateString()} • {download.size}
                    </p>
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-800">
                  Completed
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Export Guidelines */}
      <Card className="border-slate-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="w-5 h-5 mr-2 text-blue-600" />
            Export Guidelines
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="mb-2 text-slate-900">Data Privacy</h4>
              <ul className="space-y-1 text-slate-600">
                <li>• All exported data is anonymized</li>
                <li>• PHI data is encrypted and secured</li>
                <li>• Access logs are maintained for compliance</li>
              </ul>
            </div>
            <div>
              <h4 className="mb-2">File Formats</h4>
              <ul className="space-y-1 text-slate-600">
                <li>• CSV: Raw data for analysis</li>
                <li>• PDF: Formatted reports</li>
                <li>• Excel: Structured data with charts</li>
                <li>• JSON: API-compatible format</li>
              </ul>
            </div>
            <div>
              <h4 className="mb-2">Update Frequency</h4>
              <ul className="space-y-1 text-slate-600">
                <li>• Claims data: Updated hourly</li>
                <li>• Reports: Generated daily</li>
                <li>• Analytics: Refreshed every 4 hours</li>
              </ul>
            </div>
            <div>
              <h4 className="mb-2">Size Limits</h4>
              <ul className="space-y-1 text-slate-600">
                <li>• Maximum file size: 500 MB</li>
                <li>• Large datasets split automatically</li>
                <li>• Download links expire in 24 hours</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}